export function suma (num1, num2) {
    
    const result = num1 + num2
    return result
}