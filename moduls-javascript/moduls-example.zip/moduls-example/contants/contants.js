export const MIN_AGE = 0
export const MAX_AGE = 120