import { getYourAge } from "./getYourAge.js";

document.getElementById('age-button').addEventListener('click', getYourAge)


