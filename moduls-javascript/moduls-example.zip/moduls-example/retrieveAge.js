export function retrieveAge () {
    const age = document.getElementById('age-input').value;
    return age
}