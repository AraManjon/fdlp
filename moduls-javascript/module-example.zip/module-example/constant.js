export const ADULT_AGE = 18
export const MAX_AGE = 120
export const MIN_AGE = 0