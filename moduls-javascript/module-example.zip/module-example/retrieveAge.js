export function retrieveAge () {
    return document.getElementById('input-age').value
}